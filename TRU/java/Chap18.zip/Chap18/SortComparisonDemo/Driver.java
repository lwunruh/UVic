
/**
 * Driver of the Sort Comparison Demo
 * @author Java Foundations
 * @version 4.0
 */
public class Driver
{
	/**
	 * Presents the view for the Sort Comparison Demo.
	 * @param args command-line arguments (unused)
	 */
	public static void main(String[] args)
	{
		View view = new View();
	}
}